# Deployment checklist

## Simplest deployment
Use a host that supports Docker or Python ASGI apps. Build from the repository root and expose port 8000. For a public service, put the app behind a managed HTTPS reverse proxy.

## Environment
- `MSLS_DATABASE_PATH`: SQLite file path. Mount persistent storage at this path.
- `MSLS_CORS_ORIGINS`: comma-separated exact allowed origins. Do not use `*` when credentials or sensitive integrations are introduced.

## Production hardening
- Set up TLS, backups, monitoring, and a restore drill.
- Use managed PostgreSQL instead of SQLite if write concurrency or multiple application replicas are required.
- Add admin authentication before any write endpoints are introduced.
- Add rate limiting, security headers, request logging without personal medical data, and vulnerability updates.
- Add privacy policy, terms, accessibility checks, and analytics consent as applicable.
- Keep patient-identifiable data out of this public educational encyclopedia.
