# Content model and editorial guidance

Each catalog entry stores:
- `slug`: stable unique URL/API identifier
- Arabic and English test names
- abbreviation and category
- purpose, specimen, preparation, and interpretation in both languages
- keywords in both languages
- `reviewed`: editorial approval flag (defaults to false)
- `updated_at`: database timestamp

## Suggested next content fields
For a production medical encyclopedia, consider adding method, units, reference intervals by population, interfering factors, turnaround time, critical values policy, citations, source review date, author/reviewer, version history, and related tests. Do not publish a universal reference interval as applicable to every lab.

## Editorial workflow
1. Draft from reputable clinical laboratory references and local laboratory SOPs.
2. Record source URLs, publication/version, and access date.
3. Have a qualified laboratory professional review both Arabic and English.
4. Verify translation, units, assay and population-specific reference data.
5. Mark as reviewed only after documented approval.
6. Re-review periodically and whenever a source or assay changes.
