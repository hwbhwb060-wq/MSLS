import os
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from app.db import init_db, connect
from app.seed import seed

ROOT = Path(__file__).resolve().parent.parent
app = FastAPI(
    title="MSLS Medical Test Encyclopedia API",
    description="Bilingual educational medical laboratory test catalog.",
    version="1.0.0",
)
origins = [x.strip() for x in os.getenv("MSLS_CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET"], allow_headers=["*"])

@app.on_event("startup")
def startup():
    init_db()
    seed()

def localize(row, lang: str):
    d = dict(row)
    suffix = "ar" if lang == "ar" else "en"
    d["name"] = d.pop(f"name_{suffix}")
    d["purpose"] = d.pop(f"purpose_{suffix}")
    d["specimen"] = d.pop(f"specimen_{suffix}")
    d["preparation"] = d.pop(f"preparation_{suffix}")
    d["interpretation"] = d.pop(f"interpretation_{suffix}")
    d["keywords"] = d.pop(f"keywords_{suffix}", "")
    for key in list(d):
        if key.endswith("_ar") or key.endswith("_en"):
            d.pop(key, None)
    return d

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "MSLS"}

@app.get("/api/categories")
def categories(lang: str = Query("ar", pattern="^(ar|en)$")):
    labels = {
      "hematology": {"ar":"أمراض الدم","en":"Hematology"},
      "chemistry": {"ar":"الكيمياء السريرية","en":"Clinical Chemistry"},
      "hormones": {"ar":"الهرمونات","en":"Hormones"},
      "urinalysis": {"ar":"تحليل البول","en":"Urinalysis"},
      "vitamins": {"ar":"الفيتامينات","en":"Vitamins"},
      "microbiology": {"ar":"الأحياء المجهرية","en":"Microbiology"},
      "immunology": {"ar":"المناعة","en":"Immunology"},
      "coagulation": {"ar":"التخثر","en":"Coagulation"},
    }
    with connect() as conn:
        rows = conn.execute("SELECT category, COUNT(*) AS count FROM tests GROUP BY category ORDER BY category").fetchall()
    return [{"slug":r["category"], "name":labels.get(r["category"],{}).get(lang,r["category"]), "count":r["count"]} for r in rows]

@app.get("/api/tests")
def list_tests(q: Optional[str] = None, category: Optional[str] = None, lang: str = Query("ar", pattern="^(ar|en)$"), limit: int = Query(100, ge=1, le=250), offset: int = Query(0, ge=0)):
    sql = "SELECT * FROM tests WHERE 1=1"
    args = []
    if category:
        sql += " AND category = ?"
        args.append(category)
    if q and q.strip():
        needle = f"%{q.strip()}%"
        sql += """ AND (name_ar LIKE ? OR name_en LIKE ? OR abbreviation LIKE ?
                     OR keywords_ar LIKE ? OR keywords_en LIKE ? OR slug LIKE ?)"""
        args.extend([needle] * 6)
    sql += " ORDER BY name_en LIMIT ? OFFSET ?"
    args.extend([limit, offset])
    with connect() as conn:
        rows = conn.execute(sql, args).fetchall()
        count_sql = "SELECT COUNT(*) FROM tests WHERE 1=1"
        count_args = []
        if category:
            count_sql += " AND category = ?"; count_args.append(category)
        if q and q.strip():
            count_sql += """ AND (name_ar LIKE ? OR name_en LIKE ? OR abbreviation LIKE ?
                               OR keywords_ar LIKE ? OR keywords_en LIKE ? OR slug LIKE ?)"""
            count_args.extend([f"%{q.strip()}%"] * 6)
        total = conn.execute(count_sql, count_args).fetchone()[0]
    return {"items":[localize(r,lang) for r in rows], "total":total, "limit":limit, "offset":offset}

@app.get("/api/tests/{slug}")
def get_test(slug: str, lang: str = Query("ar", pattern="^(ar|en)$")):
    with connect() as conn:
        row = conn.execute("SELECT * FROM tests WHERE slug = ?", (slug,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Test not found")
    return localize(row,lang)

@app.get("/")
def index():
    return FileResponse(ROOT / "web" / "index.html")

app.mount("/static", StaticFiles(directory=ROOT / "web"), name="static")
