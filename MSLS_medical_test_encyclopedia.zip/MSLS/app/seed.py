from app.db import init_db, connect

SEED = [
    {
      "slug":"complete-blood-count","name_ar":"تعداد الدم الكامل","name_en":"Complete Blood Count",
      "abbreviation":"CBC","category":"hematology",
      "purpose_ar":"يساعد في تقييم خلايا الدم الحمراء والبيضاء والصفائح الدموية، وقد يُطلب ضمن تقييمات متعددة.",
      "purpose_en":"Assesses red cells, white cells, and platelets; it may be ordered in many clinical evaluations.",
      "specimen_ar":"عادةً عينة دم وريدي في أنبوب يحتوي على EDTA؛ اتبع تعليمات المختبر.",
      "specimen_en":"Usually venous blood collected in an EDTA tube; follow the laboratory's instructions.",
      "preparation_ar":"غالبًا لا يتطلب صيامًا، لكن اتبع تعليمات الطبيب والمختبر.",
      "preparation_en":"Fasting is often not required, but follow the clinician's and laboratory's instructions.",
      "interpretation_ar":"تُفسّر المؤشرات وعدد الخلايا مع الأعراض والعمر والجنس والحالة السريرية والمدى المرجعي للمختبر. لا يكفي هذا الفحص وحده لتشخيص مرض.",
      "interpretation_en":"Counts and indices are interpreted with symptoms, age, sex, clinical context, and the laboratory's reference intervals. This test alone does not establish a diagnosis.",
      "keywords_ar":"دم، هيموغلوبين، كريات بيضاء، صفائح",
      "keywords_en":"blood, hemoglobin, leukocytes, platelets"
    },
    {
      "slug":"fasting-plasma-glucose","name_ar":"سكر الدم الصائم","name_en":"Fasting Plasma Glucose",
      "abbreviation":"FPG","category":"chemistry",
      "purpose_ar":"يقيس مستوى الغلوكوز في البلازما بعد فترة صيام محددة، ويُستخدم ضمن تقييم اضطرابات سكر الدم.",
      "purpose_en":"Measures plasma glucose after a defined fasting period and is used in evaluating glucose disorders.",
      "specimen_ar":"عينة دم وريدي تُعالج وفق بروتوكول المختبر.",
      "specimen_en":"Venous blood processed according to the laboratory protocol.",
      "preparation_ar":"يتطلب عادةً صيامًا لمدة يحددها الطبيب أو المختبر؛ الماء غالبًا مسموح. لا تغيّر الأدوية دون توجيه طبي.",
      "preparation_en":"Usually requires fasting for a period specified by the clinician or laboratory; water is commonly allowed. Do not change medicines without medical advice.",
      "interpretation_ar":"يعتمد التفسير على الإرشادات المعتمدة والسياق السريري، وقد يتطلب تأكيد النتيجة بفحص آخر. لا تعتمد على حدود عامة دون مراجعة المختبر والطبيب.",
      "interpretation_en":"Interpretation depends on applicable guidelines and clinical context; an abnormal result may need confirmation. Do not rely on generic cutoffs without consulting the laboratory and clinician.",
      "keywords_ar":"غلوكوز، سكري، صيام",
      "keywords_en":"glucose, diabetes, fasting"
    },
    {
      "slug":"thyroid-stimulating-hormone","name_ar":"الهرمون المنبه للدرقية","name_en":"Thyroid-Stimulating Hormone",
      "abbreviation":"TSH","category":"hormones",
      "purpose_ar":"يساعد في تقييم وظيفة الغدة الدرقية، وغالبًا يُفسّر مع فحوصات درقية أخرى عند الحاجة.",
      "purpose_en":"Helps evaluate thyroid function and is often interpreted alongside other thyroid tests when indicated.",
      "specimen_ar":"عادةً عينة دم وريدي.",
      "specimen_en":"Usually a venous blood sample.",
      "preparation_ar":"قد تؤثر بعض الأدوية والمكملات في النتائج؛ أخبر الطبيب والمختبر بما تستخدمه واتبع تعليماتهما.",
      "preparation_en":"Some medicines and supplements can affect results; tell your clinician and laboratory what you take and follow their instructions.",
      "interpretation_ar":"تختلف المجالات المرجعية حسب العمر وطريقة القياس والمختبر والحمل. تُفسر النتيجة مع الأعراض ونتائج مثل FT4 عند الحاجة.",
      "interpretation_en":"Reference intervals vary by age, assay, laboratory, and pregnancy status. Interpret with symptoms and tests such as FT4 when appropriate.",
      "keywords_ar":"درقية، غدة، هرمونات، قصور، فرط",
      "keywords_en":"thyroid, gland, hormone, hypothyroidism, hyperthyroidism"
    },
    {
      "slug":"urinalysis","name_ar":"تحليل البول","name_en":"Urinalysis",
      "abbreviation":"UA","category":"urinalysis",
      "purpose_ar":"يفحص خصائص البول وبعض مكوناته الكيميائية والمجهرية للمساعدة في تقييم حالات مختلفة.",
      "purpose_en":"Examines urine characteristics and selected chemical and microscopic components to help evaluate various conditions.",
      "specimen_ar":"غالبًا عينة بول نظيفة من منتصف التبول في وعاء مناسب، حسب تعليمات المختبر.",
      "specimen_en":"Often a clean-catch midstream urine sample in a suitable container, according to laboratory instructions.",
      "preparation_ar":"اتبع تعليمات جمع العينة وتسليمها بسرعة. قد تختلف التعليمات حسب سبب الفحص.",
      "preparation_en":"Follow collection instructions and deliver the sample promptly. Instructions can vary with the reason for testing.",
      "interpretation_ar":"تُفسر النتائج بحسب الأعراض وطريقة الجمع واحتمال تلوث العينة؛ وقد يلزم زرع البول أو فحوص أخرى.",
      "interpretation_en":"Results are interpreted in light of symptoms, collection method, and possible contamination; culture or other testing may be needed.",
      "keywords_ar":"بول، بروتين، دم، كيتون، كثافة",
      "keywords_en":"urine, protein, blood, ketones, specific gravity"
    },
    {
      "slug":"vitamin-d-25-hydroxy","name_ar":"فيتامين د (25-هيدروكسي)","name_en":"25-Hydroxy Vitamin D",
      "abbreviation":"25-OH Vitamin D","category":"vitamins",
      "purpose_ar":"يُستخدم لتقييم مخزون فيتامين د في سياقات سريرية محددة.",
      "purpose_en":"Used to assess vitamin D status in selected clinical contexts.",
      "specimen_ar":"عادةً عينة دم وريدي.",
      "specimen_en":"Usually a venous blood sample.",
      "preparation_ar":"لا يتطلب الصيام عادةً، لكن اتبع تعليمات المختبر وأبلغ الطبيب عن المكملات المستخدمة.",
      "preparation_en":"Fasting is not usually required, but follow laboratory instructions and tell your clinician about supplements.",
      "interpretation_ar":"تختلف الحدود المستخدمة حسب الإرشادات والحالة الصحية وطريقة القياس. لا تبدأ جرعات علاجية عالية دون استشارة مختص.",
      "interpretation_en":"Thresholds vary with guidelines, health context, and assay. Do not start high-dose treatment without professional advice.",
      "keywords_ar":"فيتامين، عظام، كالسيوم",
      "keywords_en":"vitamin, bone, calcium"
    },
    {
      "slug":"lipid-panel","name_ar":"دهون الدم","name_en":"Lipid Panel",
      "abbreviation":"Lipid profile","category":"chemistry",
      "purpose_ar":"يقيس عادةً الكوليسترول الكلي وHDL وLDL والدهون الثلاثية للمساعدة في تقييم مخاطر القلب والأوعية.",
      "purpose_en":"Usually measures total cholesterol, HDL, LDL, and triglycerides to help assess cardiovascular risk.",
      "specimen_ar":"عينة دم وريدي.",
      "specimen_en":"Venous blood sample.",
      "preparation_ar":"قد لا يلزم الصيام في بعض الحالات، بينما قد يطلبه الطبيب أو المختبر في حالات أخرى، خاصةً بحسب الدهون الثلاثية.",
      "preparation_en":"Fasting may not be needed in some situations, but a clinician or laboratory may request it in others, particularly depending on triglycerides.",
      "interpretation_ar":"يُفسّر الملف مع عوامل الخطر والتاريخ الصحي والأدوية، وتختلف الأهداف المناسبة من شخص لآخر.",
      "interpretation_en":"Interpret the panel with risk factors, medical history, and medicines; appropriate targets differ by person.",
      "keywords_ar":"كوليسترول، دهون ثلاثية، قلب",
      "keywords_en":"cholesterol, triglycerides, cardiovascular"
    }
]

def seed():
    init_db()
    with connect() as conn:
        for item in SEED:
            cols = ", ".join(item.keys())
            placeholders = ", ".join("?" for _ in item)
            conn.execute(
                f"INSERT OR IGNORE INTO tests ({cols}) VALUES ({placeholders})",
                tuple(item.values())
            )

if __name__ == "__main__":
    seed()
    print("MSLS sample catalog seeded.")
