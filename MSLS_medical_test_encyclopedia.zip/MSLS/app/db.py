import os
import sqlite3
from pathlib import Path

def db_path() -> Path:
    path = Path(os.getenv("MSLS_DATABASE_PATH", "data/msls.db"))
    if not path.is_absolute():
        path = Path.cwd() / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path

def connect():
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS tests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          slug TEXT NOT NULL UNIQUE,
          name_ar TEXT NOT NULL,
          name_en TEXT NOT NULL,
          abbreviation TEXT DEFAULT '',
          category TEXT NOT NULL,
          purpose_ar TEXT NOT NULL,
          purpose_en TEXT NOT NULL,
          specimen_ar TEXT NOT NULL,
          specimen_en TEXT NOT NULL,
          preparation_ar TEXT NOT NULL,
          preparation_en TEXT NOT NULL,
          interpretation_ar TEXT NOT NULL,
          interpretation_en TEXT NOT NULL,
          keywords_ar TEXT DEFAULT '',
          keywords_en TEXT DEFAULT '',
          reviewed BOOLEAN NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tests_category ON tests(category)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tests_names ON tests(name_en, name_ar)")
