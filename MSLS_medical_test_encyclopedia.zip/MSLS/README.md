# MSLS — Medical Sciences Laboratory System
Bilingual (Arabic/English) medical laboratory test encyclopedia.

## Included
- Responsive RTL/LTR bilingual website
- Searchable test catalog and category filters
- FastAPI REST API backed by SQLite
- Seed catalog with sample entries (educational starter data, not a complete clinical reference)
- API tests, Docker setup, environment example, and deployment notes

## Quick start (Python 3.11+)
```bash
cd MSLS
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python -m app.seed
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs.

## Docker
```bash
docker compose up --build
```

## API
- `GET /api/health`
- `GET /api/tests?q=glucose&category=chemistry&lang=en`
- `GET /api/tests/{slug}?lang=ar`
- `GET /api/categories?lang=ar`

Supported `lang`: `ar`, `en`. `q` searches both language names, abbreviations, and keywords.
The database is created at `data/msls.db` and seeded on first startup.

## Before production deployment
1. Use HTTPS and a reputable hosting provider.
2. Configure backups and monitoring for the database.
3. Set `MSLS_CORS_ORIGINS` to the exact allowed frontend origins if frontend and API are separated.
4. Review all medical content with qualified laboratory professionals and cite authoritative sources.
5. Replace sample reference intervals with locally validated, method-specific ranges. Do not use this starter catalog to make clinical decisions.
6. Add editorial workflow, content versioning, audit logs, rate limiting, and privacy/legal pages before public launch.

## Important medical notice
MSLS is an educational information directory, not a diagnostic service. Reference intervals vary by laboratory, assay, age, pregnancy status, population, and units. Users should interpret results with a qualified clinician and the reporting laboratory.
