import os
import tempfile
from fastapi.testclient import TestClient

# Use an isolated database for tests.
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["MSLS_DATABASE_PATH"] = _tmp.name

from app.main import app
from app.seed import seed

seed()
client = TestClient(app)

def test_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_list_tests_arabic():
    response = client.get("/api/tests?lang=ar")
    assert response.status_code == 200
    body = response.json()
    assert body["total"] >= 5
    assert any(item["slug"] == "complete-blood-count" for item in body["items"])

def test_search_abbreviation():
    response = client.get("/api/tests?q=CBC&lang=en")
    assert response.status_code == 200
    assert any(item["slug"] == "complete-blood-count" for item in response.json()["items"])

def test_test_details():
    response = client.get("/api/tests/fasting-plasma-glucose?lang=en")
    assert response.status_code == 200
    assert response.json()["name"] == "Fasting Plasma Glucose"

def test_missing_test():
    response = client.get("/api/tests/not-a-real-test")
    assert response.status_code == 404

def test_invalid_language():
    response = client.get("/api/tests?lang=fr")
    assert response.status_code == 422
