const I18N={
 ar:{subtitle:"موسوعة التحاليل الطبية",eyebrow:"مرجعك الصحي المعرفي",heroTitle:"كل ما تحتاج معرفته عن التحاليل الطبية",heroText:"ابحث عن التحليل، تعرّف على نوع العينة والتحضير والتفسير العام للنتائج.",searchPlaceholder:"ابحث باسم التحليل أو الاختصار...",searchHint:"جرّب: CBC أو سكر الدم أو TSH",heroBadge:"معلومات مخبرية موثوقة",library:"المكتبة الطبية",testsTitle:"استكشف التحاليل",loading:"جارٍ تحميل التحاليل...",all:"جميع التحاليل",noticeTitle:"تنبيه طبي مهم",noticeText:"المعلومات للتثقيف فقط ولا تغني عن الطبيب. تختلف المجالات المرجعية حسب المختبر وطريقة القياس والحالة الصحية.",footer:"موسوعة التحاليل الطبية · معلومات للتثقيف الصحي",apiDocs:"توثيق واجهة API",readMore:"عرض التفاصيل",empty:"لا توجد تحاليل مطابقة لبحثك.",error:"تعذر تحميل البيانات. تأكد من تشغيل الخادم ثم أعد المحاولة.",purpose:"لماذا يُطلب التحليل؟",specimen:"نوع العينة",preparation:"التحضير قبل الفحص",interpretation:"التفسير العام",detailWarning:"التفسير العام لا يغني عن تقييم الطبيب ومرجع المختبر الذي أجرى الفحص.",hematology:"أمراض الدم",chemistry:"الكيمياء السريرية",hormones:"الهرمونات",urinalysis:"تحليل البول",vitamins:"الفيتامينات",microbiology:"الأحياء المجهرية",immunology:"المناعة",coagulation:"التخثر",testsCount:"تحليل"}
,en:{subtitle:"Medical Test Encyclopedia",eyebrow:"YOUR MEDICAL KNOWLEDGE HUB",heroTitle:"Everything you need to know about lab tests",heroText:"Search for a test and learn about specimen types, preparation, and general interpretation.",searchPlaceholder:"Search by test name or abbreviation...",searchHint:"Try: CBC, glucose, or TSH",heroBadge:"Laboratory information",library:"MEDICAL LIBRARY",testsTitle:"Explore tests",loading:"Loading tests...",all:"All tests",noticeTitle:"Important medical notice",noticeText:"For education only, not a substitute for a clinician. Reference intervals vary by laboratory, method, and health context.",footer:"Medical test encyclopedia · For health education",apiDocs:"API documentation",readMore:"View details",empty:"No tests match your search.",error:"Could not load data. Check that the server is running and try again.",purpose:"Why is it ordered?",specimen:"Specimen",preparation:"Preparation",interpretation:"General interpretation",detailWarning:"General information does not replace clinician review and the reporting laboratory's reference intervals.",hematology:"Hematology",chemistry:"Clinical chemistry",hormones:"Hormones",urinalysis:"Urinalysis",vitamins:"Vitamins",microbiology:"Microbiology",immunology:"Immunology",coagulation:"Coagulation",testsCount:"tests"}
};
let lang="ar", category="", debounce;
const $=id=>document.getElementById(id);
const categoryIcons={hematology:"◉",chemistry:"⌁",hormones:"⌘",urinalysis:"♧",vitamins:"✦",microbiology:"⌬",immunology:"✚",coagulation:"◌"};
function tr(key){return I18N[lang][key]||key}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function applyLanguage(){
 document.documentElement.lang=lang;document.documentElement.dir=lang==="ar"?"rtl":"ltr";
 document.querySelectorAll("[data-i18n]").forEach(el=>{const k=el.dataset.i18n;if(I18N[lang][k])el.textContent=I18N[lang][k]});
 document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>el.placeholder=tr(el.dataset.i18nPlaceholder));
 $("langToggle").textContent=lang==="ar"?"English":"العربية";
 loadCategories();loadTests();
}
async function loadCategories(){
 try{
  const r=await fetch(`/api/categories?lang=${lang}`);if(!r.ok)throw Error();
  const data=await r.json();
  $("categories").innerHTML=`<button class="category-btn ${category===""?"active":""}" data-category="">${tr("all")}</button>`+data.map(c=>`<button class="category-btn ${category===c.slug?"active":""}" data-category="${escapeHtml(c.slug)}">${escapeHtml(c.name)}</button>`).join("");
  $("categories").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{category=b.dataset.category;loadCategories();loadTests()}));
 }catch(e){/* tests endpoint shows the visible error state */}
}
async function loadTests(){
 $("status").className="status";$("status").textContent=tr("loading");
 const params=new URLSearchParams({lang,limit:"250"});if(category)params.set("category",category);if($("searchInput").value.trim())params.set("q",$("searchInput").value.trim());
 try{
  const r=await fetch(`/api/tests?${params}`);if(!r.ok)throw Error();const data=await r.json();
  $("resultCount").textContent=`${data.total} ${tr("testsCount")}`;
  $("testGrid").innerHTML=data.items.map(t=>`<article class="test-card" tabindex="0" role="button" data-slug="${escapeHtml(t.slug)}" aria-label="${escapeHtml(t.name)}"><div class="card-top"><span class="test-icon">${categoryIcons[t.category]||"✚"}</span><span class="tag">${escapeHtml(tr(t.category))}</span></div><h3>${escapeHtml(t.name)}</h3><p class="abbreviation">${escapeHtml(t.abbreviation||"")}</p><p class="purpose">${escapeHtml(t.purpose)}</p><span class="card-link">${tr("readMore")} ${lang==="ar"?"←":"→"}</span></article>`).join("");
  $("status").textContent=data.items.length?"":tr("empty");$("testGrid").querySelectorAll(".test-card").forEach(card=>{card.addEventListener("click",()=>openTest(card.dataset.slug));card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openTest(card.dataset.slug)}})});
 }catch(e){$("testGrid").innerHTML="";$("resultCount").textContent="";$("status").className="status error";$("status").textContent=tr("error")}
}
async function openTest(slug){
 try{
  const r=await fetch(`/api/tests/${encodeURIComponent(slug)}?lang=${lang}`);if(!r.ok)throw Error();const t=await r.json();
  $("modalCategory").textContent=tr(t.category);$("modalTitle").textContent=t.name;$("modalAbbr").textContent=t.abbreviation||"";
  const fields=[["purpose",t.purpose],["specimen",t.specimen],["preparation",t.preparation],["interpretation",t.interpretation]];
  $("modalFields").innerHTML=fields.map(([key,value])=>`<section class="detail-field"><h3>${tr(key)}</h3><p>${escapeHtml(value)}</p></section>`).join("");
  $("modal").hidden=false;document.body.style.overflow="hidden";$("modalClose").focus();
 }catch(e){$("status").className="status error";$("status").textContent=tr("error")}
}
function closeModal(){$("modal").hidden=true;document.body.style.overflow=""}
$("langToggle").addEventListener("click",()=>{lang=lang==="ar"?"en":"ar";applyLanguage()});
$("searchInput").addEventListener("input",()=>{clearTimeout(debounce);debounce=setTimeout(loadTests,180)});
$("clearSearch").addEventListener("click",()=>{$("searchInput").value="";loadTests();$("searchInput").focus()});
$("modalClose").addEventListener("click",closeModal);
$("modal").addEventListener("click",e=>{if(e.target.dataset.close)closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
$("year").textContent=new Date().getFullYear();
applyLanguage();
